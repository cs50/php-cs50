<?php

function fail1() {
}

function pass1()
{
}

function fail2(
   ) {

}

function pass2(
   )
{
}

?>